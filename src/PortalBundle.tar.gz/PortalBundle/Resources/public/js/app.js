
var ClinicApp = angular.module('AppClinic', ['ngRoute']);

// Configuración de las rutas


ClinicApp.config(function($routeProvider,$locationProvider) {
    $locationProvider.hashPrefix('');
    $routeProvider
        .when('/', {
            templateUrl: '../bundles/portal/pages/gateways.html',
            controller: 'gwController'
        })
        .when('/gateways', {
            templateUrl: '../bundles/portal/pages/gateways.html',
            controller: 'gwController'
        })
        .when('/pacientes', {
            templateUrl: '../bundles/portal/pages/pacientes.html',
            controller: 'pacientesController'
        })
        .when('/mediciones', {
            templateUrl: '../bundles/portal/pages/mediciones.html',
            controller: 'medicionesController'
        })


});

ClinicApp.controller('mainController', function($scope,$http) {
    console.log("main control");
});

ClinicApp.controller('gwController', function($scope,$http) {
    console.log("gw control");
});


ClinicApp.controller('pacientesController', function($scope,$http) {
    console.log("pacientes control");
    $scope.pacientes=new  Array();
    var getPacinests=function () {

        $http({
            method: 'GET',
            url: Routing.generate('get_pacientes')
        }).then(function (response) {

            $scope._pacientes=response.data;
            for (var a = 0; a < $scope._pacientes.length; a++) {
                $scope.paciente=$scope._pacientes[a];

                $scope.paciente.data=angular.fromJson($scope._pacientes[a].data);
                //console.log(pac);
                $scope.pacientes.push($scope.paciente);
            }

            console.log($scope.pacientes);

        });
    }

    getPacinests();
});



ClinicApp.controller('medicionesController', function($scope,$http) {

    $scope.mediciones=new  Array();
    var getData=function () {

        $http({
            method: 'GET',
            url: Routing.generate('get_mediciones')
        }).then(function (response) {

            $scope._mediciones=response.data;
            for (var a = 0; a < $scope._mediciones.length; a++) {
                $scope.medicion=$scope._mediciones[a];

                $scope.medicion.data=angular.fromJson($scope._mediciones[a].data);
                //console.log(pac);
                $scope.mediciones.push($scope.medicion);
            }

            console.log($scope.mediciones);

        });
    }

    getData();

});